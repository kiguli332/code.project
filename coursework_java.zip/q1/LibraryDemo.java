import java.util.List;

/**
 * Demonstrates the library system:
 *   - two members, three books
 *   - lend / return operations
 *   - one correctly rejected duplicate loan
 *   - library state printed before and after
 */
public class LibraryDemo {

    public static void main(String[] args) {

        // ---- Setup ----
        Library lib = new Library("City Community Library");

        Member alice = new Member("M001", "Alice Nakato");
        Member bob   = new Member("M002", "Bob Ssempa");
        lib.registerMember(alice);
        lib.registerMember(bob);

        Book b1 = new Book("978-0-13-110362-7", "The C Programming Language", "Kernighan & Ritchie");
        Book b2 = new Book("978-0-13-468599-1", "Clean Code", "Robert C. Martin");
        Book b3 = new Book("978-0-20-163361-5", "Design Patterns");   // uses 2-arg constructor
        lib.addBook(b1);
        lib.addBook(b2);
        lib.addBook(b3);

        System.out.println();

        // ---- State BEFORE any loans ----
        lib.printState();

        // ---- Lending operations ----
        System.out.println(">>> Alice borrows 'Clean Code'");
        lib.lendBook("978-0-13-468599-1", "M001");

        System.out.println("\n>>> Bob borrows 'Design Patterns'");
        lib.lendBook("978-0-20-63361-5", "M002");   // wrong ISBN – should fail gracefully

        System.out.println("\n>>> Bob borrows 'Design Patterns' (correct ISBN)");
        lib.lendBook("978-0-20-163361-5", "M002");

        System.out.println("\n>>> Alice tries to borrow 'Clean Code' again [should be REJECTED]");
        lib.lendBook("978-0-13-468599-1", "M001");  // already on loan – rejected

        System.out.println("\n>>> Bob also tries to borrow 'Clean Code' [should be REJECTED]");
        lib.lendBook("978-0-13-468599-1", "M002");  // still on loan – rejected

        // ---- State AFTER loans ----
        lib.printState();

        // ---- Return operation ----
        System.out.println(">>> Alice returns 'Clean Code'");
        lib.returnBook("978-0-13-468599-1", "M001");

        System.out.println("\n>>> Now Bob successfully borrows 'Clean Code'");
        lib.lendBook("978-0-13-468599-1", "M002");

        // ---- State AFTER return ----
        lib.printState();

        // ---- Search ----
        System.out.println(">>> Searching for books with 'code' in the title:");
        List<Book> results = lib.searchByTitle("code");
        if (results.isEmpty()) {
            System.out.println("  No books found.");
        } else {
            for (Book b : results) System.out.println("  " + b);
        }

        // ---- OOP Explanations (printed as part of the run) ----
        System.out.println("\n===== OOP Concept Explanations =====");
        System.out.println(
            "Association: A Loan associates a Member with a Book temporarily.\n" +
            "  The Loan object holds references to both but neither owns the other.\n\n" +
            "Aggregation: (not used here – would apply if a Library contained Books\n" +
            "  that could exist independently, e.g. pre-existing books brought in.)\n\n" +
            "Composition: Library COMPOSES Books and Members.\n" +
            "  If the Library ceases to exist, the Books and Members in its\n" +
            "  collections are no longer meaningful – their lifecycle is tied to\n" +
            "  the Library. That is why we chose composition.\n\n" +
            "Multiplicity '1..*': 'one or more'.\n" +
            "  Example from our diagram: A Member holds 1..* Loans means a member\n" +
            "  must have at least one active loan for a Loan to exist, but can have\n" +
            "  many loans concurrently."
        );
    }
}
