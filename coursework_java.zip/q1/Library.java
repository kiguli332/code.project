import java.util.ArrayList;
import java.util.List;

/**
 * Holds the collection of all Books and Members and provides
 * operations to add, lend, return and search.
 *
 * Relationship notes:
 *   Library –-COMPOSITION–> Book   (books are created for and owned by this library)
 *   Library –-COMPOSITION–> Member (members are registered with and owned by this library)
 *   Loan is an ASSOCIATION between Member and Book (exists independently of the library)
 */
public class Library {

    private String       name;
    private List<Book>   books;    // composition: Library owns its Books
    private List<Member> members;  // composition: Library owns its Members

    public Library(String name) {
        this.name    = name;
        this.books   = new ArrayList<>();
        this.members = new ArrayList<>();
    }

    // ---------- Adding items ----------

    /** Adds a book to the library's collection. */
    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added: " + book.getTitle());
    }

    /** Registers a new member with the library. */
    public void registerMember(Member member) {
        members.add(member);
        System.out.println("Member registered: " + member.getName());
    }

    // ---------- Lending ----------

    /**
     * Lends a book (identified by ISBN) to a member (identified by member ID).
     * Enforces the "at most one active loan per book" business rule.
     *
     * @return the new Loan if successful, or null if rejected.
     */
    public Loan lendBook(String isbn, String memberId) {
        Book   book   = findBookByIsbn(isbn);
        Member member = findMemberById(memberId);

        if (book == null) {
            System.out.println("ERROR: Book with ISBN " + isbn + " not found.");
            return null;
        }
        if (member == null) {
            System.out.println("ERROR: Member with ID " + memberId + " not found.");
            return null;
        }
        if (!book.isAvailable()) {
            // Graceful rejection – business rule enforced here
            System.out.println("REJECTED: \"" + book.getTitle() + "\" is already on loan.");
            return null;
        }

        // Create the loan, update states
        Loan loan = new Loan(member, book);
        book.setAvailable(false);
        member.addLoan(loan);
        System.out.println("SUCCESS: \"" + book.getTitle() + "\" lent to " + member.getName() + ".");
        return loan;
    }

    // ---------- Returning ----------

    /**
     * Returns a book (identified by ISBN) from a member (identified by member ID).
     */
    public void returnBook(String isbn, String memberId) {
        Book   book   = findBookByIsbn(isbn);
        Member member = findMemberById(memberId);

        if (book == null || member == null) {
            System.out.println("ERROR: Book or member not found.");
            return;
        }

        // Find the matching active loan
        Loan targetLoan = null;
        for (Loan loan : member.getLoans()) {
            if (loan.getBook().getIsbn().equals(isbn)) {
                targetLoan = loan;
                break;
            }
        }

        if (targetLoan == null) {
            System.out.println("ERROR: No active loan found for this book and member.");
            return;
        }

        book.setAvailable(true);
        member.removeLoan(targetLoan);
        System.out.println("SUCCESS: \"" + book.getTitle() + "\" returned by " + member.getName() + ".");
    }

    // ---------- Search ----------

    /**
     * Searches for books whose title contains the given keyword (case-insensitive).
     */
    public List<Book> searchByTitle(String keyword) {
        List<Book> results = new ArrayList<>();
        for (Book b : books) {
            if (b.getTitle().toLowerCase().contains(keyword.toLowerCase())) {
                results.add(b);
            }
        }
        return results;
    }

    // ---------- Private helpers ----------

    private Book findBookByIsbn(String isbn) {
        for (Book b : books) {
            if (b.getIsbn().equals(isbn)) return b;
        }
        return null;
    }

    private Member findMemberById(String memberId) {
        for (Member m : members) {
            if (m.getMemberId().equals(memberId)) return m;
        }
        return null;
    }

    // ---------- Display ----------

    /** Prints the current state of all books and members. */
    public void printState() {
        System.out.println("\n===== Library State: " + name + " =====");
        System.out.println("--- Books ---");
        for (Book b : books) System.out.println("  " + b);
        System.out.println("--- Members ---");
        for (Member m : members) {
            System.out.println("  " + m);
            for (Loan l : m.getLoans()) System.out.println("      " + l);
        }
        System.out.println("==========================================\n");
    }

    @Override
    public String toString() {
        return String.format("Library[Name=%s, Books=%d, Members=%d]",
                name, books.size(), members.size());
    }
}
