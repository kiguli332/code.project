/**
 * Demonstrates the Shape hierarchy:
 *   - polymorphism via printAreas()
 *   - largest() utility
 *   - InvalidShapeException caught in a try-catch
 *   - resize() demo
 */
public class ShapeDemo {

    /**
     * Prints the area of each shape through the superclass reference.
     * Dynamic binding ensures the correct getArea() override runs at runtime.
     */
    public static void printAreas(Shape[] shapes) {
        System.out.println("--- Areas (via dynamic binding) ---");
        for (Shape s : shapes) {
            // s.getArea() is resolved at runtime to the actual subclass method
            System.out.printf("  %s -> area = %.2f%n",
                    s.getClass().getSimpleName(), s.getArea());
        }
    }

    /**
     * Returns the shape with the largest area.
     */
    public static Shape largest(Shape[] shapes) {
        Shape max = shapes[0];
        for (int i = 1; i < shapes.length; i++) {
            if (shapes[i].getArea() > max.getArea()) {
                max = shapes[i];
            }
        }
        return max;
    }

    public static void main(String[] args) {

        // ---- Create valid shapes ----
        Shape[] shapes = {
            new Circle(5.0, "red", true),
            new Rectangle(4.0, 6.0, "blue", false),
            new Triangle(3.0, 4.0, 5.0, "green", true)
        };

        System.out.println("===== All Shapes =====");
        for (Shape s : shapes) System.out.println("  " + s);
        System.out.println();

        // ---- printAreas (polymorphism / dynamic binding) ----
        printAreas(shapes);
        System.out.println();

        // ---- Largest shape ----
        Shape big = largest(shapes);
        System.out.println("Largest shape: " + big);
        System.out.println();

        // ---- Resize demo ----
        System.out.println(">>> Resize Circle by factor 2:");
        shapes[0].resize(2.0);
        System.out.println("  After resize: " + shapes[0]);
        System.out.println();

        // ---- Invalid triangle caught with try-catch ----
        System.out.println(">>> Attempting to create an invalid triangle (1, 2, 10):");
        try {
            Triangle bad = new Triangle(1, 2, 10);   // violates triangle inequality
            System.out.println("  Created (should NOT reach here): " + bad);
        } catch (InvalidShapeException e) {
            System.out.println("  Caught InvalidShapeException: " + e.getMessage());
        }

        // ---- Invalid resize caught ----
        System.out.println("\n>>> Attempting resize with factor -1:");
        try {
            shapes[1].resize(-1);
        } catch (InvalidShapeException e) {
            System.out.println("  Caught InvalidShapeException: " + e.getMessage());
        }

        // ---- OOP Explanations ----
        System.out.println("\n===== OOP Concept Explanations =====");
        System.out.println(
            "Dynamic Binding (Polymorphism):\n" +
            "  In printAreas(), the line 's.getArea()' calls the method on a Shape\n" +
            "  reference. At RUNTIME Java resolves which getArea() to use based on\n" +
            "  the actual object type (Circle, Rectangle or Triangle). That is why\n" +
            "  Circle -> area prints 78.54 (PI*5^2) and Triangle -> area prints 6.00\n" +
            "  without any instanceof checks in printAreas().\n\n" +
            "Why Shape is abstract:\n" +
            "  A 'generic shape' has no meaningful area or perimeter on its own –\n" +
            "  only concrete subclasses do. Declaring Shape abstract prevents\n" +
            "  accidental instantiation. If you write 'new Shape()' the compiler\n" +
            "  immediately reports: \"Shape is abstract; cannot be instantiated\"."
        );
    }
}
