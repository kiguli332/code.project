/**
 * A circle defined by its radius.
 */
public class Circle extends Shape {

    private double radius;

    public Circle(double radius) {
        validate(radius);
        this.radius = radius;
    }

    public Circle(double radius, String color, boolean filled) {
        super(color, filled);
        validate(radius);
        this.radius = radius;
    }

    private void validate(double r) {
        if (r <= 0) {
            throw new InvalidShapeException(
                "Circle radius must be positive, but got: " + r);
        }
    }

    public double getRadius()           { return radius; }
    public void   setRadius(double r)   { validate(r); this.radius = r; }

    @Override public double getArea()      { return Math.PI * radius * radius; }
    @Override public double getPerimeter() { return 2 * Math.PI * radius; }

    @Override
    public void resize(double factor) {
        if (factor <= 0) throw new InvalidShapeException(
                "Resize factor must be positive, but got: " + factor);
        radius *= factor;
    }

    @Override
    public String toString() {
        return String.format("Circle[radius=%.2f, color=%s, filled=%b, area=%.2f, perimeter=%.2f]",
                radius, color, filled, getArea(), getPerimeter());
    }
}
