/**
 * Thrown when a shape is constructed with invalid dimensions,
 * or when resize() is called with a non-positive factor.
 *
 * Design choice – UNCHECKED (extends RuntimeException):
 *   Invalid dimensions are programming errors (passing -5 as a radius),
 *   not recoverable conditions a caller should be forced to handle at
 *   every call site. Using an unchecked exception keeps client code clean
 *   while still allowing optional catching where appropriate.
 */
public class InvalidShapeException extends RuntimeException {

    public InvalidShapeException(String message) {
        super(message);
    }
}
