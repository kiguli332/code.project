/**
 * A rectangle defined by width and height.
 */
public class Rectangle extends Shape {

    private double width;
    private double height;

    public Rectangle(double width, double height) {
        validate(width, height);
        this.width  = width;
        this.height = height;
    }

    public Rectangle(double width, double height, String color, boolean filled) {
        super(color, filled);
        validate(width, height);
        this.width  = width;
        this.height = height;
    }

    private void validate(double w, double h) {
        if (w <= 0 || h <= 0) {
            throw new InvalidShapeException(
                "Rectangle dimensions must be positive. Got width=" + w + ", height=" + h);
        }
    }

    public double getWidth()            { return width; }
    public double getHeight()           { return height; }
    public void   setWidth(double w)    { if (w <= 0) throw new InvalidShapeException("Width must be positive."); width  = w; }
    public void   setHeight(double h)   { if (h <= 0) throw new InvalidShapeException("Height must be positive."); height = h; }

    @Override public double getArea()      { return width * height; }
    @Override public double getPerimeter() { return 2 * (width + height); }

    @Override
    public void resize(double factor) {
        if (factor <= 0) throw new InvalidShapeException(
                "Resize factor must be positive, but got: " + factor);
        width  *= factor;
        height *= factor;
    }

    @Override
    public String toString() {
        return String.format("Rectangle[width=%.2f, height=%.2f, color=%s, filled=%b, area=%.2f, perimeter=%.2f]",
                width, height, color, filled, getArea(), getPerimeter());
    }
}
