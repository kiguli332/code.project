/**
 * A triangle defined by three sides (a, b, c).
 * Uses Heron's formula for area.
 */
public class Triangle extends Shape {

    private double a, b, c;

    public Triangle(double a, double b, double c) {
        validate(a, b, c);
        this.a = a; this.b = b; this.c = c;
    }

    public Triangle(double a, double b, double c, String color, boolean filled) {
        super(color, filled);
        validate(a, b, c);
        this.a = a; this.b = b; this.c = c;
    }

    private void validate(double a, double b, double c) {
        if (a <= 0 || b <= 0 || c <= 0) {
            throw new InvalidShapeException(
                "All triangle sides must be positive. Got: " + a + ", " + b + ", " + c);
        }
        // Triangle inequality
        if (a + b <= c || a + c <= b || b + c <= a) {
            throw new InvalidShapeException(
                "Invalid triangle: sides " + a + ", " + b + ", " + c +
                " violate the triangle inequality.");
        }
    }

    public double getSideA() { return a; }
    public double getSideB() { return b; }
    public double getSideC() { return c; }

    @Override
    public double getArea() {
        double s = getPerimeter() / 2.0;          // semi-perimeter
        return Math.sqrt(s * (s - a) * (s - b) * (s - c));  // Heron's formula
    }

    @Override public double getPerimeter() { return a + b + c; }

    @Override
    public void resize(double factor) {
        if (factor <= 0) throw new InvalidShapeException(
                "Resize factor must be positive, but got: " + factor);
        a *= factor; b *= factor; c *= factor;
    }

    @Override
    public String toString() {
        return String.format("Triangle[a=%.2f, b=%.2f, c=%.2f, color=%s, filled=%b, area=%.2f, perimeter=%.2f]",
                a, b, c, color, filled, getArea(), getPerimeter());
    }
}
