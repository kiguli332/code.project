/**
 * Abstract base class for all geometric shapes.
 * Cannot be instantiated directly – use Circle, Rectangle or Triangle.
 */
public abstract class Shape {

    protected String  color  = "white";
    protected boolean filled;

    /** Default constructor. */
    public Shape() { }

    /** Full constructor. */
    public Shape(String color, boolean filled) {
        this.color  = color;
        this.filled = filled;
    }

    // ---------- Abstract methods ----------

    /** Returns the area of this shape. */
    public abstract double getArea();

    /** Returns the perimeter of this shape. */
    public abstract double getPerimeter();

    /**
     * Scales all linear dimensions by the given factor.
     * @throws InvalidShapeException if factor <= 0.
     */
    public abstract void resize(double factor);

    // ---------- Getters / Setters ----------

    public String  getColor()             { return color; }
    public boolean isFilled()             { return filled; }
    public void    setColor(String color) { this.color  = color; }
    public void    setFilled(boolean f)   { this.filled = f; }

    @Override
    public String toString() {
        return String.format("Shape[color=%s, filled=%b, area=%.2f, perimeter=%.2f]",
                color, filled, getArea(), getPerimeter());
    }
}
